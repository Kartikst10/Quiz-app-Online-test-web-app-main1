# Quiz-app-Online-test-web-app


#Steps to run the code
1. Download the zip files and extract them and place them in one folder let folder name be project
2. open folder project in vscode
3. open terminal in vs code and change directory by "cd client" command
4. run command "npm install" in the client directory
5. open .env file present in server directory
6. create cluster in mongodb, you can refer youtube for this and get the link for your cluster
7. create cloudinary account you can get name, api secret, api key there
8. replace DB_URI, CLOUDINARY_CLOUD_NAME, CLOUDINARY_API_SECRET, CLOUDINARY_API_KEY 
9. now open another terminal run "cd server"
10. run "node index.js" in server terminal 
11. run "nodemon index.js" in client terminal
12. You can create accounts, add quiz, take quiz Enjoyy!!




![image](https://user-images.githubusercontent.com/120095574/217866467-06b9fcbc-b884-4ecd-92d7-9644709f530a.png)


For createtest image url you can choose any image from web and copy adress
![image](https://user-images.githubusercontent.com/120095574/217868807-3eb2a148-6238-4c5e-af46-c8ede976c451.png)

Available Tests section
![image](https://user-images.githubusercontent.com/120095574/217869197-1f4dd3c5-ec39-4ebd-bdd0-dd030a98e7c4.png)


